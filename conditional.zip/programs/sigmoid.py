import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-3.1, 3.1, 100)
y = 1/(1+np.exp(-x))

plt.figure(figsize=(8, 6))
plt.plot(x, y, '-b', linewidth=3)
plt.plot([-3.1, 3.1], [0, 0], '-k', linewidth=2)
plt.plot([0, 0], [0, 1], '-k', linewidth=2)
plt.xlabel("z", size=26, weight='bold')
plt.ylabel("g(z)", size=26, weight='bold')
plt.xticks(size=26, weight='bold')
plt.yticks([0, 1], size=26, weight='bold')
plt.tight_layout()
plt.show()