# AI in the Built Environment

# Dr. Aamir Alaud Din

# November 26, 2025

# Objectives

1. To understand and explain the logic behind dimension reduction.
2. To understand the underlying mathematics in dimension reduction via principal component analysis (PCA).

# The Why Section

- Environmental data is often a data matrix of several features and training examples.
- It is not possible to visualize all the features in the real feature space.
- However, if we are able to reduce the dimensions of data, we can visualize the reduced dimensions data in the PC space.
- However, we don't know how to reduce the dimension using some mathematics.
- The only objective of this topic is to learn how to reudce the dimensionality.

# Explanation

We start with a **complete hand-calculated PCA worked example** for the 3 environmental features (Flow, BOD, TSS) using the small 8-observation dataset shown in table below. We show every step: means, standard deviations, standardization (z-scores), correlation matrix, eigenvalues/eigenvectors, percent variance explained, and finally **PC scores** with one entry computed by hand to understand and check the arithmetic.

We will be limited to 6 decimal places in our calculations.

---

# 1. Data (n = 8, p = 3)

| Obs | Flow (m³/s) | BOD (mg/L) | TSS (mg/L) |
| --: | :---------: | :--------: | :--------: |
|   1 |     2.5     |     30     |     45     |
|   2 |     3.0     |     35     |     50     |
|   3 |     2.8     |     33     |     48     |
|   4 |     3.2     |     40     |     60     |
|   5 |     2.0     |     20     |     30     |
|   6 |     2.2     |     22     |     33     |
|   7 |     3.5     |     45     |     70     |
|   8 |     1.8     |     18     |     25     |

---

# 2. Step 1 — Means and sample standard deviations

Means (columnwise):
\[
\bar{x} = [2.625,\ 30.375,\ 45.125]
\]

Sample standard deviations:
\[
s = [0.601783,\ 9.753205,\ 15.366359]
\]

These are computed in the usual way: $(s=\sqrt{\tfrac{1}{n-1}\sum (x_i-\bar{x})^2})$.

---

# 3. Step 2 — Standardize (z-scores)

Standardize each entry: $(z_{ij}=(x_{ij}-\bar{x}_j)/s_j)$.

We show the standardized vector for observation 1 as an explicit check:

Obs 1 raw = (2.5, 30, 45)

* Flow: $(z = (2.5-2.625)/0.601783 = -0.125/0.601783 \approx -0.207716)$
* BOD:  $(z = (30-30.375)/9.753205 = -0.375/9.753205 \approx -0.038449)$
* TSS:  $(z = (45-45.125)/15.366359 = -0.125/15.366359 \approx -0.008135)$

Full standardized matrix (Z) (rounded):

| Obs |      Flow |       BOD |       TSS |
| --: | --------: | --------: | --------: |
|   1 | -0.207716 | -0.038449 | -0.008135 |
|   2 |  0.623148 |  0.474203 |  0.317251 |
|   3 |  0.290802 |  0.269142 |  0.187097 |
|   4 |  0.955494 |  0.986855 |  0.968024 |
|   5 | -1.038580 | -1.063753 | -0.984293 |
|   6 | -0.706235 | -0.858692 | -0.789061 |
|   7 |  1.454012 |  1.499507 |  1.618796 |
|   8 | -1.370926 | -1.268814 | -1.309679 |

(Each column has mean ≈ 0 and sample sd ≈ 1)

---

# 4. Step 3 — Correlation matrix \(R)

Because we standardized, the sample correlation matrix = $(R = \frac{1}{n-1} Z^\top Z)$.

Computed \(R) (rounded):

\[
R \approx
\begin{bmatrix}
1.000000 & 0.993667 & 0.986784 \\
0.993667 & 1.000000 & 0.995736 \\
0.986784 & 0.995736 & 1.000000
\end{bmatrix}
\]

Interpretation: all three variables are very strongly positively correlated.

---

# 5. Step 4 — Eigen decomposition of \(R)

Solve $(R v = \lambda v)$. The eigenvalues (sorted descending) and their eigenvectors (columns) are:

**Eigenvalues** (rounded):
\[
\lambda_1 = 2.984129,\quad \lambda_2 = 0.013349,\quad \lambda_3 = 0.002522.
\]

Check: $(\lambda_1+\lambda_2+\lambda_3 = \mathrm{trace}(R) = 3)$ (OK).

**Percent variance explained** by each PC:

* PC1: $(100 \times 2.984129/3 \approx 99.47\%)$
* PC2: $(100 \times 0.013349/3 \approx 0.445\%)$
* PC3: $(100 \times 0.002522/3 \approx 0.084\%)$

So nearly all variance is on PC1.

**Eigenvectors (loadings)** — columns correspond to PC1, PC2, PC3 (rounded):

\[
V =
\begin{bmatrix}
-0.576637 & -0.748260 &  0.328018\\
-0.578372 &  0.090298 & -0.810760\\
-0.577040 &  0.657231 &  0.484842
\end{bmatrix}
\]

Interpretation of PC1 loadings: $(v_1 \approx [-0.5766,\ -0.5784,\ -0.5770]^T)$.
All loadings have nearly the same magnitude ⇒ PC1 is essentially the *equal-weight* direction where Flow, BOD and TSS move together.

> Note: eigenvector signs are arbitrary (you may see these multiplied by −1 in some software); interpretation uses relative magnitudes.

---

# 6. Step 5 — Compute PC scores (projection)

Principal component scores matrix $(S) (size (n\times p))$ is:

\[
S = Z  V
\]

That is, each PC score = inner product of the standardized observation with the chosen eigenvector.

We give one **hand calculation** for Obs 1 on PC1 to show arithmetic:

$Obs1 (z) = ([-0.207716,\ -0.038449,\ -0.008135])$ and $(v_1 = [-0.576637,\ -0.578372,\ -0.577040])$.

Compute PC1 score:
\[
\begin{aligned}
\text{PC1}_1 &= (-0.207716)(-0.576637) + (-0.038449)(-0.578372) + (-0.008135)(-0.577040) \\
&\approx 0.119700 + 0.022226 + 0.004783 \\
&\approx 0.146709.
\end{aligned}
\]

This matches the PC1 score below.

Full scores (rounded):

| Obs |       PC1 |       PC2 |       PC3 |
| --: | --------: | --------: | --------: |
|   1 |  0.146709 |  0.146607 | -0.040906 |
|   2 | -0.816663 | -0.214950 | -0.026244 |
|   3 | -0.431314 | -0.070327 | -0.032109 |
|   4 | -1.680331 |  0.010369 | -0.017345 |
|   5 |  1.782106 |  0.034165 |  0.044548 |
|   6 |  1.359205 | -0.067687 |  0.081965 |
|   7 | -2.639821 |  0.111347 |  0.046063 |
|   8 |  2.280111 |  0.050476 | -0.055973 |

(These are rows of (ZV).)

---

# 7. Interpretation — what loadings and scores tell us here

* **Loadings (columns of (V))**:

  * PC1 loadings ≈ equal weights on Flow, BOD, TSS → PC1 measures the common mode: when PC1 is large (positive or negative depending on sign convention) the three variables are jointly large (or jointly small). Because of the negative signs, a positive PC1 score corresponds to the observation being *below* the mean for those variables in our sign convention; absolute sign is arbitrary.
  * PC2 and PC3 have tiny eigenvalues → they capture negligible residual structure (nearly all variance is along PC1).

* **Scores (rows of (S))**:

  * They give each observation’s coordinate along the principal axes.
  * Since PC1 explains ≈ 99.47% of variance, **PC1 alone** is an excellent one-dimensional summary of these samples.
  * Example: Obs 8 has PC1 = 2.280111 (largest positive) — it is the most extreme in the PC1 direction (i.e., far from the mean in the same sense as the PC1 loadings).
  * Observations with similar PC1 scores are similar in the original variables (because PC1 captures the common correlated trend).

---

# 8. Quick checklist so you can replicate by hand / in Excel

1. Compute column means and sample sds.
2. Standardize: $(Z = (X-\bar{X})/s)$.
3. Correlation matrix: $(R = \tfrac{1}{n-1} Z^\top Z)$.
4. Solve eigenproblem $(R v = \lambda v)$ (you can use a calculator/Excel’s eigen add-ins or compute by hand for small p).
5. Order eigenpairs by descending $(\lambda)$. $Percent variance = (\lambda_j / \sum \lambda)$.
6. $Scores = (ZV)$. For $PC_j$ score of observation $i$: dot product of row $(z_i)$ with $(v_j)$.

---

If you’d like, I can now:

* Show the **same PCA but using the covariance matrix** (no standardization) to contrast results; **or**
* Export the full step-by-step calculations into an Excel file (with intermediate columns, formulas, and results) and give it to you; **or**
* Draw a 2D scatter of PC1 vs PC2 with labels and show which observations are outliers.


