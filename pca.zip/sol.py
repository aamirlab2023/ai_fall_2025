import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


df = pd.read_excel('data.xlsx')

data = df[['Flow', 'BOD', 'TSS']]
data = np.array(data)

means = np.mean(data, axis=0)
stdevs = np.std(data, axis=0, ddof=1)

z = (data - means)/stdevs

cor_mat = np.corrcoef(z.T)

eigenvalues, eigenvectors = np.linalg.eig(cor_mat)

print(eigenvectors)
print(np.matmul(z, eigenvectors))


