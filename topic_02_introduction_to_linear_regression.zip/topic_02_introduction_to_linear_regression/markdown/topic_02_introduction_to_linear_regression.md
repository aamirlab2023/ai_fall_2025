<div style="padding-left: 40px; padding-right: 40px;">

<div style="font-size: 72px; text-align: center; font-weight: bold; background-color: black; padding-top: 30px; padding-bottom: 30px;">

<span style="color: white;">🧠 AI in the Built Environment</span>

<span style="color: orange;">📝 Linear Regression</span>

<span style="color: red;">🎓 Dr. Aamir Alaud Din</span>

<span style="color: green;">📅 September 9, 2025</span>

</div>



<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 10px;">

Outline

</div>



<div style="font-size: 42px; padding-left: 80px;">

1. Objectives

2. The Why Section

3. Assumptions and Limitations of the Model

4. Criteria of Best Fit Line

5. Fitting Best Fit Line (Simple Linear Regression)

6. Summary

7. Exercises

</div>

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

1. Objectives

</div>

<div style="font-size: 42px; padding-left: 40px;">

After <span style="color: green;">learning this topic</span> and <span style="color: red;">studying</span>, you should be able to

</div>

<div style="font-size: 42px; padding-left:80px;">

- Explain the concept of linear regression.

- Explain the mathematics lying behind linear regression.

- Fit a straight line $y = a + bx$ through the given data points using pen, paper, and a calculator without using any software.

- Verify the solution using software (Microsoft Excel or Python with any package).

</div>

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

2. The Why Section

</div>

<div style="font-size: 42px; padding-left: 80px;">

- There are three major sources of data

<div>

<div style="font-size: 42px; padding-left: 60px;">

1. Experiments
2. Surveys
3. Sampling

</div>

- Consider the following data obtained by sampling.

</div>

<div style="text-align: center; font-size: 42px;"><span style="font-weight: bold;">Table 1.</span> COD and nitrates data from water samples.</div>

<div style="font-size: 42px;">

|Sr. No.|COD (mg/L)|Nitrates (mg/L)|
|:---|:---|:---|
|1|25|1.2|
|2|40|2.0|
|3|18|1.0|
|4|35|1.8|
|5|15|0.9|
|6|42|2.1|

- What information do you get from this data?

- One reason of studying this topic is to know what information does a dataset give us.

- How to know if a simple mathematical relation like $y = a + bx$ represent a dataset?

- The second reason of studying this topic is to know how to determine whether a linear model like $y = a + bx$ be used.

- If a linear model is applicable to a dataset, what should be the value of $b$ (the slope or tilt of the line) and $a$ where does the line with a particular slope crosses the y-axis?

- In other words, we want to know those values of $a$ and $b$ for which the line passes very closely to all the data points and such a line will be called the best fit line.

- The third reason of studying this topic is to know the underlying mathematics to determine $a$ and $b$ for the best fit line.

- We will write our own program to determine $a$ and $b$ for any **complete** dataset and match our results with the machine learning model.

- So, the fourth reason of studying this topic is to show that artificial intelligence and machine learning is not like a human brain, but, mathematics and computer programming is working behind the model.

- Suppose we collect another sample from the same system from which the above data was generated, we measure COD to be 31 mg/L, then how much will be the concentration of Nitrate in the sample without performing a chemical analysis?

- Another reason of studying this topic is to know the output at some given input without experiments or analysis.

- It will be surprising for your that machine learning models work differently from the procedure adopted.

- However, it is true that this procedure is the foundation of the linear regression model in machine learning algorithms.

- Our final reason of studying this topic is to develop the machine learning algorithm of linear regression and use it.

</div>

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

3. Assumptions and Limitations of the Model

</div>

- Consider Table 1 again, what information do you get?

- If we rearrange the data in ascending order of COD, the data will look like the data shown in Table 2.

<div style="text-align: center;"><span style="font-weight: bold;">Table 2.</span> COD and nitrates data on the basis of COD ascending basis.</div>

|Sr. No.|COD (mg/L)|Nitrates (mg/L)|
|:---|:---|:---|
|1|15|0.9|
|2|18|1.0|
|3|25|1.2|
|4|35|1.8|
|5|40|2.0|
|6|42|2.1|

- It can be seen that both the dataset (COD and nitrates) increase together.

- But, there is no guarantee that they are strongly correlated.

- However to fit a line, the data must be correlated.

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

4. Criteria of Best Fit Line

</div>

- We want to fit (draw) a line through the data points such that the line passes in maximum closeness to all the data points.

- In other words, we need to adjust the slope and intercept of the line.

- There must be a mathematical criteria of best fit.

- One such criteria is the residual, which is the difference in y-coordinates of original data and the value of y obtained from the best fit line.

- The sum of all the residuals must be minimum.

- If negative and positive residuals are equal numerically, the sum of resdiduals will be zero.

- If we represent residual with $R$, then

$$
\sum R = 0
$$

<div style="padding-left: 20px;">which states that all the points lie on the line.</div>

- Another criterial is to compute the sum of the squared residuals $(\sum R^2)$ which will be positive in case of negative as well as positive residuals, and therefore

$$
\sum R^2 \ne 0
$$

- So, it is a good idea to minimize $\sum R^2$ for line to be best fit through the data.

***

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

5. Fitting Best Fit Line (Simple Linear Regression)

</div>

- We see $y_i$, &nbsp;$\hat {y_i}$, and $R$ in figure 1 below.

<div style="text-align: center;">

![terms](../images/0101.png)


<span style="font-weight: bold;">Figure 1.</span> A line through data points showing original data point (green color points), fitted data point (red), and residual.

</div>

- Now, we start finding the best slope and intercept.

- Suppose the equation of fitted line is $y = a + bx$.

- Also,

<div style="font-size: 42px;">

$$
R_i = y_i - \hat y_i
$$

$$
R_i = y_i - (a + bx_i)
$$

- Squares of residulas is

$$
R_i^2 = [y_i - (a + bx_i)]^2
$$

- Sum of squares of residuals is

$$
\sum R_i^2 = \sum [y_i - (a + bx_i)]^2
$$

- Note that $x_i$ and $y_i$ are not the variables in the above equations because they are the fixed data points and we can't change them.

- $R_i^2$ will change with parameters $a$ and $b$ and so they are the variables we need to adjust to minimize sum of squared residuals.

- In order to minimize the sum of squared residuals, its derivatives with respect to $a$ and $b$ must be zero.

- Mathematically,

$$
\frac{\partial \sum R_i^2 }{\partial a} = 0\;\;\;\text{and}\;\;\; \frac{\partial \sum R_i^2 }{\partial b} = 0
$$

$$
\frac{\partial \sum R_i^2 }{\partial a} = 0
$$

$$
\frac{\partial \sum [y_i - (a + bx_i)]^2 }{\partial a} = 0
$$

$$
2\sum [y_i - (a + bx_i).(-1)] = 0
$$

$$
\sum [y_i - (a + bx_i)] = 0
$$

$$
\sum y_i - \sum a - \sum bx_i = 0
$$

$$
\sum a + \sum b_xi = \sum y_i
$$

$$
na + b \sum x_i = \sum y_i
$$

$$
\frac{\partial \sum R_i^2 }{\partial b} = 0
$$

$$
\frac{\partial \sum [y_i - (a + bx_i)]^2 }{\partial b} = 0
$$

$$
2\sum[y_i - (a + bx_i).(-x_i)] = 0
$$

$$
\sum[y_i - (a + bx_i).(x_i)] = 0
$$

$$
\sum [x_i y_i - ax_i - bx_i^2] = 0
$$

$$
\sum x_i y_i - a \sum x_i - b \sum x_i^2 = 0
$$

$$
a \sum x_i + b \sum x_i^2 = \sum x_i y_i
$$

- Note that we have the following two equations in two unknowns.

$$
na + b \sum x_i = \sum y_i
$$

$$
a \sum x_i + b \sum x_i^2 = \sum x_i y_i
$$

- In matrix form,

$$
\begin{bmatrix}
n & \sum x_i \\
\sum x_i & \sum x_i^2
\end{bmatrix} 
\begin{bmatrix}
a \\
b
\end{bmatrix}

= 

\begin{bmatrix}
\sum y_i \\
\sum x_i y_i
\end{bmatrix}
$$

</div>

- Now comes another new thing, which is solution to the system of equations the software packages way which is none of the below.

  - Inverse of coefficient matrix times the column vector of right hand side

  - Row operations

  - Cramer's rule

- Let's dig it out by solving the data posed in the why section.

***
***

<span style="color: green;">Example 1</span>

Fit the straight line through the data such that the sum of squared residuals is minimum.

|$x_i$|$y_i$|$x_i^2$|$x_i y_i$|
|:---|:---|:---|:---|
|25|1.2|625|30|
|40|2.0|1600|80|
|18|1.0|324|18|
|35|1.8|1225|63|
|15|0.9|225|13.5|
|42|2.1|1764|88.2|
|$\sum x_i = 175$|$\sum y_i = 9$|$\sum x_i^2 = 5763$|$\sum x_i y_i = 292.7$|

<span style="color: green;">Solution</span>

- Our data matrix equation is now shown below.

$$
\begin{bmatrix}
6 & 175 \\
175 & 5763
\end{bmatrix}
\begin{bmatrix}
a \\
b
\end{bmatrix} = 
\begin{bmatrix}
9 \\
292.7
\end{bmatrix}
$$

- Solving this system will give the parameters $a$ and $b$.

***
***

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

6. Summary

</div>

- A line (regression line) can fit into data if there is a correlation in the data.

- The criteria of best fit line is that the sum of squared residuals must be minimum.

- The criteria of best fit can be accomplished by setting first derivatives of the sum of squared residuals with respect to the system parameters.

- The first derivatives of the sum of squared residuals with respect to the system parameters give a system of equations that can be written in matrix form.

- In the matrix form of system of equations, the solution gives the values of parameters which are the coefficients of the best fit line.

<div style="color: orange; font-size: 52px; font-weight: bold; background-color: black; border-left: solid red 20px; padding-left: 40px;">

7. Exercises

</div>

<span style="color: green; font-weight: bold;">Exercise 1</span>

Given the independent variables $x$ and $y$ and the dependent variable $z$. Our objective is fit the 3d plane throught the data having the mathematical relation

$$
z = a + bx + cy
$$

Develope the relation of the sum of squared residuals, and then minimize it. Develop the system of equations and convert them into matrix form.

<span style="color: green; font-weight: bold;">Exercise 2</span>
Given the following data

|Sr. No.|$x$|$y$|$z$|
|:---|:---|:---|:---|
|1|2.5|13.5|60.5|
|2|3.5|17.1|85.1|
|3|4.7|8.2|40.5|
|4|1.5|1.3|12.0|
|5|5.0|15.6|70.2|

Fit the best fit plane of the form

$$
z = a + bx + cy
$$

through the data. Plot the data and the best fit plane through the data.

<span style="color: green; font-weight: bold;">Exercise 3</span>

Given the independent variables $x$ the dependent variable $y$. Our objective is fit the parabola throught the data having the mathematical relation

$$
y = a + bx + cx^2
$$

Develope the relation of the sum of squared residuals, and then minimize it. Develop the system of equations and convert them into matrix form.

<span style="color: green; font-weight: bold;">Exercise 4</span>

Develop a synthetic data of your choice and fit the parabola through it.

</div>
