import numpy as np
import matplotlib.pyplot as plt

# data
x = np.array([25, 40, 18, 35, 15, 42])
y = np.array([1.2, 2.0, 1.0, 1.8, 0.9, 2.1])

b, a = np.polyfit(x, y, 1)

print(f"Slope (b): {b:.4f}")
print(f"Intercept (a): {a:.4f}")

print("Equation is:")
print(f"y = {a:.4f} + {b:.4f}x")

y_predicted = a + b*x

plt.scatter(x, y, color='blue', label='Data Points')
plt.plot(x, y_predicted, color='red', label=f"y = {a:.4f} + {b:.4f}x")
plt.legend()
plt.show()
