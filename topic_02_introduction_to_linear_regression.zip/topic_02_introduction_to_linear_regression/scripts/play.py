import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Data
x = np.array([2.5, 3.5, 4.7, 1.5, 5.0])
y = np.array([13.5, 17.1, 8.2, 1.3, 15.6])
z = np.array([10.2, 15.3, 9.8, 3.2, 12.6])  # Example z values

# Design matrix: [1, x, y]
X = np.c_[np.ones(len(x)), x, y]

# Solve least squares (z = X * coeffs)
coeffs, _, _, _ = np.linalg.lstsq(X, z, rcond=None)

a, b, c = coeffs
print(f"Plane equation: z = {a:.3f} + {b:.3f}x + {c:.3f}y")

# Predictions
z_pred = X @ coeffs

# --- Plot ---
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Scatter original data points
ax.scatter(x, y, z, color='blue', label='Data points')

# Create meshgrid for surface
x_range = np.linspace(min(x), max(x), 20)
y_range = np.linspace(min(y), max(y), 20)
X_grid, Y_grid = np.meshgrid(x_range, y_range)
Z_grid = a + b * X_grid + c * Y_grid

# Plot fitted plane
ax.plot_surface(X_grid, Y_grid, Z_grid, alpha=0.5, color='red')

# Labels
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.legend()
plt.show()

n = len(x)
sxi = np.sum(x)
syi = np.sum(y)
sxi2 = np.sum(x*x)
sxiyi = np.sum(x*y)
syi2 = np.sum(y*y)
szi = np.sum(z)
sxizi = np.sum(x*z)
syizi = np.sum(y*z)

x_1 = np.array([[n, sxi, syi],
                [sxi, sxi2, sxiyi],
                [syi, sxiyi, syi2]])
b_1 = np.array([[szi],
                [sxizi],
                [syizi]])

print(np.matmul(np.linalg.inv(x_1), b_1))