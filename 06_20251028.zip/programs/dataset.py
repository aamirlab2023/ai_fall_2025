import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


remainder = 0
while remainder == 0:
    k = int(input("Enter k-value: "))
    remainder = k%2

xlo = [1, 1, -1, -1, -1, -1, 1, 1]
xhi = [5, 5, -5, -5, -5, -5, 5, 5]
ylo = [1, -1, 1, -1, 1, -1, 1, -1]
yhi = [5, -5, 5, -5, 5, -5, 5, -5]
zlo = [1, 1, 1, 1, -1, -1, -1, -1]
zhi = [5, 5, 5, 5, -5, -5, -5, -5]

x = np.array([])
for i in range(8):
    if xlo[i] > xhi[i]:
        start = xhi[i]
        stop = xlo[i]
    else:
        start = xlo[i]
        stop = xhi[i]
    xnew = np.random.randint(start, stop, size=5) + np.random.rand(5)
    x = np.append(x, xnew, axis=0)

y = np.array([])
for i in range(8):
    if ylo[i] > yhi[i]:
        start = yhi[i]
        stop = ylo[i]
    else:
        start = ylo[i]
        stop = yhi[i]
    ynew = np.random.randint(start, stop, size=5) + np.random.rand(5)
    y = np.append(y, ynew, axis=0)

z = np.array([])
for i in range(8):
    if zlo[i] > zhi[i]:
        start = zhi[i]
        stop = zlo[i]
    else:
        start = zlo[i]
        stop = zhi[i]
    znew = np.random.randint(start, stop, size=5) + np.random.rand(5)
    z = np.append(z, znew, axis=0)

true_labels = np.repeat(["A", "B", "C", "D", "E", "F", "G", "H"], 5)

for i in range(len(x)):
    print(f"{x[i]:.2f},{y[i]:.2f},{z[i]:.2f},{true_labels[i]}")

new_point = np.array([4.91, 2.71, -3.6])

distances = np.sqrt((x - new_point[0])**2 + (y - new_point[1])**2 + (z - new_point[2])**2)

sorted_d = np.sort(distances)
sorted_i = np.argsort(distances)

nearest = sorted_i[:k]

selected = true_labels[nearest]
print(selected)

fig = plt.figure(figsize=(6, 5))
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x, y, z, c='b', marker='o', s=50)
ax.scatter(new_point[0], new_point[1], new_point[2], c='r', marker='o', s=50)
for i in nearest:
    ax.plot([new_point[0], x[i]], [new_point[1], y[i]], [new_point[2], z[i]], '--g')
plt.show()