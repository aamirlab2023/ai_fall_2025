import numpy as np
import matplotlib.pyplot as plt

def predict(w, x):
    f = w*x
    return f

def cost(w, x, y):
    j = (1/6)*sum((y-x)**2)
    return j

i = 5
ws = [0, 0.5, 1.0, 1.5, 2.0]
#ws = np.linspace(-0.5, 2.5, 100)
Js = []
for w in ws:
    x = np.array([1, 2, 3])
    y = predict(w, x)
    Js.append(cost(w, x, y))
    plt.scatter (x, x, marker="X", c="r", s=80)
    plt.plot(x, y, '-b', linewidth=3)
    plt.xlim([0, 3.5])
    plt.ylim([0, 6.5])
    plt.xticks([0, 1, 2, 3], size=18, weight="bold")
    plt.yticks([0, 1, 2, 3, 4, 5, 6], size=18, weight="bold")
    plt.xlabel("x", size=18, weight="bold")
    plt.ylabel("y", size=18, weight="bold")
    plt.tight_layout()
    plt.savefig(f"030{i}.png")
    plt.show()
    i += 1

print(Js)

plt.scatter(ws, Js, marker="X", s=80, c="r")
plt.plot(ws, Js, "-b", linewidth=3.0)
plt.xticks(size=18, weight="bold", rotation="vertical")
plt.yticks(size=18, weight="bold")
plt.xlabel("w", size=18, weight="bold")
plt.ylabel("J(w)", size=18, weight="bold")
plt.tight_layout()
plt.show()