import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

x = np.linspace(-5, 5, 50)
y = np.linspace(-5, 5, 50)
X, Y = np.meshgrid(x, y)
Z = (X**2 + Y**2)


fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')
#ax.plot_wireframe(X, Y, Z, rstride=2, cstride=2)
surf = ax.plot_surface(X, Y, Z, cmap="inferno", edgecolor="k", linewidth=0.3)
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.show()

fig, ax = plt.subplots(figsize=(7, 6))   # make a figure + axis

#contour_filled = ax.contour(X, Y, Z, levels=5, cmap="viridis")  # filled contours
contour_lines = ax.contour(X, Y, Z, levels=50, colors="black", linewidths=0.5)  # contour lines

# --- Add colorbar to explain values -----------------------------------------
#cbar = plt.colorbar(contour_filled, ax=ax)
#cbar.set_label("Z value")

# --- Labels and title -------------------------------------------------------
ax.set_title("Contour plot with meshgrid")
ax.set_xlabel("X axis")
ax.set_ylabel("Y axis")

plt.show()


