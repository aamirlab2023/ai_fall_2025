import random as random
import matplotlib.pyplot as plt

nitrates = []
algae_growth = []
for i in range(50):
    nitrate = random.randint(1, 10) + random.random()
    nitrates.append(nitrate)
    algae_growth.append(5*nitrate + random.randint(0, 5))

for i in range(len(nitrates)):
    print(nitrates[i], algae_growth[i])

f = open("growth.csv", "w")
for counter, nitrate in enumerate(nitrates):
    f.writelines(f"{nitrate:.2f},{algae_growth[counter]:.2f}\n")

plt.scatter(nitrates, algae_growth, marker="X", c="r")
plt.show()