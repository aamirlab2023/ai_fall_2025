import matplotlib.pyplot as plt

with open("data.txt", "r") as infile:
    lines = infile.readlines()
infile.close()

salinity = []
price = []
for line in lines:
    line = line.split(",")
    print(line)
    salinity.append(float(line[0]))
    price.append(float(line[1]))

plt.scatter(salinity, price, c='r', marker="x", s=80)
plt.xlabel("Salinity", size=12, weight="bold")
plt.ylabel("Price (PKR/L)", size=12, weight="bold")
plt.xticks(size=12, weight="bold")
plt.yticks(size=12, weight="bold")
plt.xlim([0, 50])
plt.ylim([0, 2.5])
plt.tight_layout()
plt.show()