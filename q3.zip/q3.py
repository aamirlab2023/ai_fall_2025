import numpy as np


p = np.array([-7.2, 8.5, -6.5])

f = open("dq3.txt", "r")
lines = f.readlines()
f.close()

data = []
for line in lines:
    d = []
    line = line.split(",")
    d.append(float(line[0]))
    d.append(float(line[1]))
    d.append(float(line[2]))
    data.append(d)

data = np.array(data)

p1 = np.array([5, 7, 9])
p2 = np.array([[10, 14, 18], [15, 21, 27]])

print(p1 - p2)
print((p1 - p2)**2)
print(sum(((p1 - p2)**2).T))
print(np.sqrt(sum(((p1 - p2)**2).T)))

print(np.sqrt(sum(((p - data)**2).T)))

