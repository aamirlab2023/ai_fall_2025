# Objectives
1. To understand the concept of k-means cluster.
2. To understand and apply the underlying mathematics to make clusters of the data.
3. To know how to decide the number of clusters initially.

# The Why Section

- If we plot the complete data set on a scatter diagram, it is not possible to identify the cluster of data.
- However, mathematical magics and tricks help us to make cluster of data.
- The first reason of studying this topic is to know how the mathematics helps to make clusters of data.
- The problem is that we don't know how many cluster to try for a given dataset.
- Again, mathematics and logic helps us to decide the number of clusters to try.
- The second and last reason of studying this topic is to know how to decide the final number of clusters in the data and make clusters.


# What is k-means clustering — short and practical

**k-means** is a simple, widely used algorithm that groups (clusters) data points into `k` clusters so that points in the same cluster are similar. It does this by:

1. Choosing `k` initial **centroids** (points that represent clusters).
2. Repeating until convergence:

   * **Assign** each data point to the nearest centroid (by Euclidean distance).
   * **Recompute** each centroid as the mean (average) of the points assigned to it.

The algorithm tries to minimize the sum of squared distances from each point to its cluster centroid (called the SSE — sum of squared errors).

---

# Foundation mathematics you need

1. **Vectors and coordinates** — points as `(x, y, ...)`.
2. **Euclidean distance** between two points $(p=(x_1,y_1))$ and $(q=(x_2,y_2))$:
   \[
   d(p,q)=\sqrt{(x_1-x_2)^2+(y_1-y_2)^2}.
   \]
   When comparing distances you can compare squared distances (no need to take square roots).
3. **Mean (average)** — centroid for a cluster of ($n$) points $((x_i,y_i))$ is
   \[
   \bar x=\frac{1}{n}\sum_{i} x_i,\quad \bar y=\frac{1}{n}\sum_{i} y_i.
   \]
4. **Objective (SSE)**: sum of squared Euclidean distances of points to their centroids:
   \[
   SSE=\sum_{\text{clusters}}\sum_{p\in\text{cluster}} |p-\text{centroid}|^2.
   \]
5. **Basic algebra** (squaring, addition, comparison).

---

# Worked example — *manual* k = 2 on a tiny 2-D dataset

Dataset (six points):

* $(P_1=(1,2))$
* $(P_2=(1,4))$
* $(P_3=(1,0))$
* $(P_4=(10,2))$
* $(P_5=(10,4))$
* $(P_6=(10,0))$

We select **$k = 2$**.
Choose initial centroids (common simple choice: pick two points):

* $(C_1^{(0)} = P_3 = (1,0))$
* $(C_2^{(0)} = P_5 = (10,4))$

I’ll show assignments and centroid recomputations step-by-step (do arithmetic digit-by-digit where helpful).

---

## Iteration 1 — assign each point to the nearest centroid

We compare squared Euclidean distances (no square roots needed because sqrt is monotonic).

### Distances to $(C_1^{(0)}=(1,0))$ and $(C_2^{(0)}=(10,4))$

**Point $(P_1=(1,2))$:**

* to $(C_1): ((1-1)^2 + (2-0)^2 = 0^2 + 2^2 = 0 + 4 = 4.)$
* to $(C_2): ((1-10)^2 + (2-4)^2 = (-9)^2 + (-2)^2 = 81 + 4 = 85.)$
  Compare: $(4 < 85)$ → assign $(P_1)$ to cluster 1.

**Point $(P_2=(1,4))$:**

* to $(C_1): (0^2 + 4^2 = 16.)$
* to $(C_2): ((-9)^2 + (0)^2 = 81 + 0 = 81.)$
  Compare: $(16 < 81)$ → assign $(P_2)$ to cluster 1.

**Point $(P_3=(1,0))$:**

* to $(C_1): (0^2 + 0^2 = 0.)$
* to $(C_2): ((-9)^2 + (-4)^2 = 81 + 16 = 97.)$
  Compare: $(0 < 97)$ → assign $(P_3)$ to cluster 1.

**Point $(P_4=(10,2))$:**

* to $(C_1): ((10-1)^2 + (2-0)^2 = 9^2 + 2^2 = 81 + 4 = 85.)$
* to $(C_2): ((10-10)^2 + (2-4)^2 = 0^2 + (-2)^2 = 0 + 4 = 4.)$
  Compare: $(4 < 85)$ → assign $(P_4)$ to cluster 2.

**Point $(P_5=(10,4))$:**

* to $(C_1): (9^2 + 4^2 = 81 + 16 = 97.)$
* to $(C_2): (0^2 + 0^2 = 0.)$
  Compare: $(0 < 97)$ → assign $(P_5)$ to cluster 2.

**Point $(P_6=(10,0))$:**

* to $(C_1): (9^2 + 0^2 = 81 + 0 = 81.)$
* to $(C_2): (0^2 + (-4)^2 = 0 + 16 = 16.)$
  Compare: $(16 < 81)$ → assign $(P_6)$ to cluster 2.

**Resulting clusters after Iteration 1:**

* Cluster A (assigned to $(C_1)): (P_1, P_2, P_3)$ → coordinates $((1,2), (1,4), (1,0))$.
* Cluster B (assigned to $(C_2)): (P_4, P_5, P_6)$ → coordinates $((10,2), (10,4), (10,0))$.

---

## Recompute centroids (means)

**Cluster A centroid**: average $x$ and $y$ of $(P_1,P_2,P_3)$:

* $(\bar x = (1+1+1)/3 = 3/3 = 1.)$
* $(\bar y = (2+4+0)/3 = 6/3 = 2.)$
  So $(C_1^{(1)} = (1,2))$.

**Cluster B centroid**: average $x$ and $y$ of $(P_4,P_5,P_6)$:

* $(\bar x = (10+10+10)/3 = 30/3 = 10.)$
* $(\bar y = (2+4+0)/3 = 6/3 = 2.)$
  So $(C_2^{(1)} = (10,2))$.

Centroids changed from $((1,0),(10,4))$ to $((1,2),(10,2))$. Continue.

---

## Iteration 2 — reassign with new centroids $(C_1^{(1)}=(1,2)), (C_2^{(1)}=(10,2))$

Compute squared distances quickly:

**$(P_1=(1,2))$:** to $(C_1): (0^2+0^2=0)$. to $(C_2): ((-9)^2+0^2=81)$. → Cluster A.

**$(P_2=(1,4))$:** to $(C_1): (0^2+2^2=4)$. to $(C_2): ((-9)^2+2^2=81+4=85)$. → Cluster A.

**$(P_3=(1,0))$:** to $(C_1): (0^2+(-2)^2=4)$. to $(C_2): ((-9)^2+(-2)^2=81+4=85)$. → Cluster A.

**$(P_4=(10,2))$:** to $(C_1): (9^2+0^2=81)$. to $(C_2): (0^2+0^2=0)$. → Cluster B.

**$(P_5=(10,4))$:** to $(C_1): (9^2+2^2=81+4=85)$. to $(C_2): (0^2+2^2=4)$. → Cluster B.

**$(P_6=(10,0))$:** to $(C_1): (9^2+(-2)^2=81+4=85)$. to $(C_2): (0^2+(-2)^2=4)$. → Cluster B.

Assignments did **not** change. Recomputing centroids will give the same $((1,2))$ and $((10,2))$ — so the algorithm **converged**.

---

## Objective (SSE) check — numeric reduction

Compute SSE (sum of squared distances to each cluster centroid).

* With final centroids $(C_1=(1,2)), (C_2=(10,2))$:

Cluster A squared distances:

* $(P_1): (0)$
* $(P_2): (4)$
* $(P_3): (4)$
  Sum = $(0+4+4 = 8.)$

Cluster B squared distances:

* $(P_4): (0)$
* $(P_5): (4)$
* $(P_6): (4)$
  Sum = $(0+4+4 = 8.)$

Total $SSE = (8 + 8 = 16.)$

* For comparison initial SSE with centroids $((1,0))$ and $((10,4))$ (iteration 0):

  * Distances squared we computed earlier sum to $(40)$.
  * So SSE decreased from $(40)$ to $(16)$, showing improvement.

---

# Final result (for this dataset)

* **k = 2** clusters found:

  * Cluster 1 centroid: $((1,2))$ with points $((1,2),(1,4),(1,0))$.
  * Cluster 2 centroid: $((10,2))$ with points $((10,2),(10,4),(10,0))$.
* Algorithm converged in **2 iterations** in this example.
* SSE final = **16** (lower is better).

---

# Notes & tips

* k-means depends on the initial centroids (different starts can give different final clusters). Common remedies: run k-means multiple times with random starts and pick the solution with smallest SSE.
* k-means assumes roughly spherical clusters and uses Euclidean geometry; it’s sensitive to scaling of features (standardize if features are on different scales).
* For more clusters (k > 2) you repeat the same math — compute distances, assign, recompute means — until centroids stop changing.


















# Model Selection

## ✅ **1. How to decide the number of centroids *before* the first iteration?**

You must **choose a value of k (number of clusters)** **before** running k-means.
The algorithm itself cannot choose k — you decide it.

Common starting guesses:

* You know how many groups exist (e.g., Male/Female → k=2)
* You inspect the dataset visually (scatter plot)
* You use heuristics such as √(n/2)

But in most real scenarios, we use systematic methods (see Section 4 below).

---

## ✅ **2. If we change the number of centroids…**

You simply rerun k-means with the new **k**.

k-means must be run separately for:

* k = 1
* k = 2
* k = 3
* …
* up to a reasonable maximum (see next section)

Then compare their performance using metrics (SSE, silhouette score, etc.)

---

## ✅ **3. What maximum number of centroids should we try?**

General guidelines:

### ✔ **Rule of thumb (#1)**

Try k from **1 to √n** where **n = number of observations**.

Example:

* n = 300 → try k = 1 to 17

### ✔ **Rule of thumb (#2)**

Try k from **1 to 10** whenever data size is moderate (< 1000 points).
Meaningful clusters rarely exceed 10.

### ✔ **Rule of thumb (#3)**

Try k up to **20** only if the dataset is large or complex.

### ❌ Do NOT try k = n

That gives every point its own cluster → meaningless.

---

## ✅ **4. How to finally decide the number of centroids?**

We use **cluster validity indices**.
Here are the standard methods:

---

### 🎯 **Elbow Method (SSE plot)** — Most Popular

Compute SSE for each k:

\[
\text{SSE}(k) = \sum_{i=1}^n |x_i - c_{z_i}|^2.
\]

Plot SSE vs k:

```
     |
SSE  |\
     | \
     |  \
     |   \__
     |       \__
     +-----------------
          k
```

✔ The “elbow” or sharp bend gives the best k.
Beyond that point, adding clusters reduces SSE very slowly.
