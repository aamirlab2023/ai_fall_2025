<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>

<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">🧠 AI in the Built Environment</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Linear Regression in Machine Learning</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">📅 September 23, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Linear Regression Model</li>
    <li>Working of the Model</li>
    <li>Cost Function</li>
    <li>The Optimization Problem</li>
    <li>Visualization and Intuition into Cost Function in Higher Dimensions</li>
    <li>Gradient Descent Method of optimization</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A line (regression line) can fit into data if there is a correlation in the data.</li>
    <li>The criteria of best fit line is that the sum of squared residuals must be minimum.</li>
    <li>The criteria of best fit can be accomplished by setting first derivatives of the sum of squared residuals with respect to the system parameters.</li>
    <li>The first derivatives of the sum of squared residuals with respect to the system parameters give a system of equations that can be written in matrix form.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Describe the linear regression process in your own words.</li>
    <li>Explain the terminologies for linear regression model.</li>
    <li>Develop the cost function for linear regression model and explain it.</li>
    <li>Develop the optimization problem and use it for a simplified regression model for an intuition into optimization of the cost function and show it graphically.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We developed the regression model $\hat y = a + bx$ using calculus and linear algebra.</li>
    <li>However for every new problem, we always need to use calculus to develop the system of equations and then solve the system of equation.</li>
    <li>Although the solution to the system of equations is generalized (echelon form is numerical way) but developing system of equations with varying problem has to be done independently for different regresion models.</li>
    <li>We want some numerical way to attack the regression problem such that we don't need to develop the system of equations for every new regression model.</li>
    <li>One reason of studying this topic is to learn how optimization works to optimize the cost function to minimize it and find the best fit line paramters.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Linear Regression Model</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Linear regression model fits a straight line (in one dimensional data) or a higher dimensional plane (in multi dimensional data) through the data.</li>
    <li>It is approximately the most used model in the world today.</li>
    <li>The concepts gained here will also be applied to other machine learning models.</li>
    <li>That's why we will spend enough time on it.</li>
    <li>Consider the data of saline in units of parts per thousand $ppt$ water in Rahim Yar Khan and its vicinity and prices for desalination in $PKR/L$.</li>
    <li><a href="../programs/data.txt" download>Click here</a> to download the dataset.</li>
    <li>We need to develop the linear regression model which is a line passing through the data as shown in figure 1 below.</li>
    </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0301.png" width="60%" alt="regress"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Data of salinity plotted against production cost per liter of water.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If the salinity of the new feedstock is $38 ppt$, we can estimate the production cost per liter of RO water.</li>
    <li>This is shown in figure 2.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0302.png" width="60%" alt="est"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 2.</strong> Linear regression line as an estimator of production cost per liter of water for a given salinity.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We provide data (with right answers) to the model and it fits a straight line for estimation of production cost per liter of water.</li>
    <li>Note that the model predicts numbers as the output, therefore, it is a regression model.</li>
    <li>There are also models other than linear regression which estimate the output as numbers.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Terminologies</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The dataset which we use for training the model is called the training dataset.</li>
    <li>After getting the model trained, we give a new input and get the estimated output.</li>
    <li>This input is represented by $x$ and is called input, input variable, feature, or input feature.</li>
    <li>The output of the model is represented by $y$ and is called the output variable or target variable.</li>
    <li>Our data has 6 data points and are called the number of training examples represented by $m$ and so $m=6$.</li>
    <li>A single training example is represented by the pair $(x, y)$ and for the third training example in our dataset $(x,y) = (18, 1.0)$.</li>
    <li>The $i$<sup>th</sup> training example is represented by $(x^{(i)}, y^{(i)})$, for example, the 3<sup>rd</sup> training example is $(x^{(3)}, y^{(3)}) = (18, 1.0)$.</li>
    <li>Note that $x^{(3)}$ doesn’t mean a cube of $x$ but the feature of 3<sup>rd</sup> training example.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Working of the Model</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We want to see what linear regression model does and what is its output.</li>
    <li>We already know that the training set includes the training features and targets.</li>
    <li>We provide features and targets to train the model.</li>
    <li>The supervised learning algorithm will produce a function $f$.</li>
    <li>Note that in a Python program we provide the function $f$ for some mathematical computation but in case of supervised learning algorithm, the algorithm develops the function $f$ from training set.</li>
    <li>A new input $x$ is provided to $f$ and it produces the output represented by $\hat y$.</li>
    <li>In machine learning, $\hat y$ is called the estimate or prediction of the model for the input $x$.</li>
    <li>If we summarize, $x$ is called feature, $f$ is called model, and $\hat y$ is called the prediction or estimated value of $y$.</li>
    <li>Note the difference that $y$ is called the target which is the true or actual value and $\hat y$ is predicted value of $y$.</li>
    <li>In case of a new input $x$ in our salinity and RO water production example, for salinity level of $38\;ppt$, $\hat y = 2.0$ which is not true value.</li>
    <li>The true value $y$ will be known after performing experiment.</li>
    <li>The figure below summarizes the working of linear regression model.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0303.png" width="100%" alt="flowchart"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 3.</strong> Working of a supervised linear regression model.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We want to know how to represent the function $f$ mathematically.</li>
    <li>It is represented by the following formula</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
f_{w, b}(x) = wx + b
$$
</span>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">where $w$ and $b$ are numbers we will learn to determine the machine learning way.</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The value of $w$ and $b$ determine the estimated $y$.</li>
    <li>The formula describes that $f$ is the function which takes $x$ as input and depending upon the value of $w$ and $b$, $f$ will output the prediction.</li>
    <li>We will also use $f(x)$ in place of $f_{w,b}(x)$ for simplicity.</li>
    <li>Sometimes, if the data is not linear, the non linear functions may be used which have the same concept.</li>
    <li>We will see a non linear learning model as well in the upcoming lectures.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Cost Function</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>First step in machine learning is to develop the cost function.</li>
    <li>Cost function tells us how well the model is fitted and will predict.</li>
    <li>We already have input features $x$ which is salinity and the target $y$ the production cost of RO water per liter.</li>
    <li>The model we are going to fit this training dataset is</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_{w, b}(x) = wx + b
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the model, $w$ and $b$ are called parameters of the model.</li>
    <li>In machine learning, parameters are adjusted during training in order to improve the model.</li>
    <li>Sometimes, these parameters are also termed as coefficients or weights.</li>
    <li>Let's look into what parameters $w$ and $b$ do.</li>
    <li>Depending on the values of $w$ and $b$, we get a different function $f(x)$ giving line of different slopes and intercepts on the graph.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0304.png" width="80%" alt="lines"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 4.</strong> Different regression lines due to varying $w$ and $b$.</figcaption>
</figure><br>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 1</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Case 1 refers to extreme left graph in which $w = 0$ and $b = 0.5$.</li>
    <li>The regression equation is</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
f(x) = 0.x + 0.5 = 0.5
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The regression plot is parallel to x-axis and the target $\hat y$ is constant for all input features $x$.</li>
    <li>The height of $y-axis$ where regression line intersects is also called y-intercept.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 2</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>This case is releated to middle plot in figure 4.</li>
    <li>The regression coefficients are $w = 0.5$ and $b = 0$.</li>
    <li>These coefficients yield the regression equation given by</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
f(x) = 0.5x + 0 = 0.5x
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The regression equation informs that target is one half of input feature.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 3</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The right most plot in figure 4 refers to case 3.</li>
    <li>The regression coefficients are $w = 0.5$ and $b= 0.5$ giving rise to following regression equation</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
f(x) = 0.5x + 0.5
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The regression equation cleary indicates that target is always one half of input feature and crosses y-axis at $y = 0.5$.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Cost Function</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The error in prediction is given by</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\hat y - y
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The error in the $i$<sup>th</sup> training point is</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\hat y^{(i)} - y^{(i)}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The errors may be positive and negative and it is a possibility that positive and negative errors cancel each other.</li>
    <li>This leads to the following mathematical equation which is logically impossible always.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\sum_i^m (\hat y^{(i)} - y^{(i)}) = 0
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>However, the sum of squared errors is not always zero as given by following equation.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\sum_i^m (\hat y^{(i)} - y^{(i)})^2 \ne 0
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Note that as the number of training examples increase, the total squared error increases.</li>
    <li>For 5 training examples, total squared error will be much minimum than that of a dataset with 100 training examples.</li>
    <li>To avoid this, we take the average error as given by the following equation.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\frac{1}{m} \sum_i^m (\hat y^{(i)} - y^{(i)})^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Finally, we make another amendment in the equation which is the use of $2m$ in the denominator instead of $m$.</li>
    <li>Since the model is empirical, there is no harm in dividing by $2m$ and it will make our further calculations easier.</li>
    <li>Some texts divide by $m$ and some divide by $2m$ and we stick to the later one.</li>
    <li>The finalized expression is the cost function and is represented by $J(w, b)$.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w, b) = \frac{1}{2m} \sum_i^m (\hat y^{(i)} - y^{(i)})^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Sometimes, this expression is also called squared error cost function.</li>
    <li>In machine learning, different cost functions are used in different applications.</li>
    <li>However, the squared error cost function is the most commonly used cost function in regression analysis.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. The Optimization Problem</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We know that</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\hat y^{(i)} = f_{w, b}(x^{(i)}) = wx^{(i)} + b
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We also know that the cost function is</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w, b) = \frac{1}{2m} \sum_i^m (f_{w, b}(x^{(i)}) - y^{(i)})^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We have to find the values of $w$ and $b$ which minimize the cost function.</li>
    <li>Now, first we want to see what cost function is computing.</li>
    <li>In other words, we are going to see what if $J(w, b)$ is large versus the cost $J(w, b)$ is small.</li>
    <li>We see an example to have an idea how the cost function helps to find the best parameter $w$ and $b$.</li>
    <li>Before solving the examples we see what we need.</li>
    <li><strong>Model: </strong>$f_{w, b} = wx + b$ is the regression model.</li>
    <li><strong>Parameters: </strong>The coefficients $w$ and $b$ are the model parameters and depending on the values $w$ and $b$ chosen, we get different straight lines.</li>
    <li><strong>Cost Function: </strong>To measure how well a choice for $w$ and $b$ fits the training data, we have the cost function which measures the difference between the model's prediction and the actual value to make the cost function as small as possible.</li>
    <li><strong>Goal: </strong>Our goal is the optimization problem of minimizing $J$ as a function of $w$ and $b$.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{aligned}
    & \min_{w,b} J(w, b)
\end{aligned}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We understand this optimization problem with the help of a more simplified version of the model given below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We have only one parameter $w$ and the cost function will be written as shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w) = \frac{1}{2m} \sum_{i=1}^m (f_w(x^{(i)}) - y^{(i)})^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Our optimization problem is now as below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{aligned}
    & \min_w J(w)
\end{aligned}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In order to understand the difference between $f(x)$ and $J(w)$ in simplified model, which is also applicable for the full model, we generate the data of cost function for varying parameters and plot it to find optimal point.</li>
    <li>Before showing the difference table, we first discuss one fact.</li>
    <li><strong>Fact: </strong>Notice that, $f_w(x)$ is a function of $x$ while $J(w)$ is a function of $w$.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We compare $f_w(x)$ and $J(w)$ for different values of $w$ and generate the data $(w, J(w))$ and plot it.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 1: $w=0$</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx = 0.x = 0
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The computation of $f_w(x)$ is given below.</li>
    <li>For $x = 1, 2, 3$, $f_w(x)=0,0,0$ and its plot is given below.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0305.png" width="40%" alt="fig05"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 5.</strong> Plot of $f_w(x)$ against $x$ for $w=0$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Cost function calculations are given below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w) = \frac{1}{2m} \sum_{i=1}^m (f_w(x^{(i)}) - y^{(i)})^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w) = \frac{1}{2 \times 3} \left[ (f_w(x^{(1)}) - y^{(1)})^2 + (f_w(x^{(2)}) - y^{(2)})^2 + (f_w(x^{(3)}) - y^{(3)})^2 \right]
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(0) = \frac{1}{2 \times 3} \left[ (0 - 1)^2 + (0 - 2)^2 + (0 - 3)^2 \right] = \frac{1}{6} \times 14 = 2.33
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Another data point to plot $J(w)$ againt $w$ is $(w, J(w)) = (0, 2.33)$.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 2: $w = 0.5$</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx = 0.5x
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The computation of $f_w(x)$ is as below.</li>
    <li>For $x = 1, 2, 3$, $f_w(x) = 0.5, 1.0, 1.5$, and its plot is shown below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0306.png" width="40%" alt="fig06"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 6.</strong> Plot of $f_w(x)$ vs $x$ for $w=0.5$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The computation of cost function is as follows.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(0.5) = \frac{1}{2 \times 3} \left[ (0.5 - 1)^2 + (1.0 - 2)^2 + (1.5 - 3)^2 \right] = \frac{1}{6} \times 3.5 = 0.58
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Our next data point for the plot of $J(w)$ against $w$ is $(w, J(w)) = (0.5, 0.58)$.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 3: $w = 1$</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx = 1.x = x
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For $x=1,2,3$, $f_w(x)=1,2,3$ and a plot of $x$ and $f_w(x)$ is shown below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0307.png" width="40%" alt="fig07"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 7.</strong> Plot of $f_w(x)$ against $x$ for $w=1$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now, we compute $J(w)$.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(1.0) = \frac{1}{2 \times 3} \left[ (1 - 1)^2 + (2 - 2)^2 + (3 - 3)^2 \right] = 0
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So, one of our data point is $(w, J(w)) = (1.0, 0.00)$</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 4: $w=1.5$</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx = 1.5x
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The computation of $f_w(x)$ is given below.</li>
    <li>For $x = 1, 2, 3$, $f_w(x)=1.5,3.0,4.5$ and its plot is given below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0308.png" width="40%" alt="fig08"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 8.</strong> Plot of $f_w(x)$ against $x$ for $w=1.5$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Cost function calculations are given below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(1.5) = \frac{1}{2 \times 3} \left[ (1.5 - 1)^2 + (3.0 - 2)^2 + (4.5 - 3)^2 \right] = \frac{1}{6} \times 3.5 = 0.58
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Another data point to plot $J(w)$ againt $w$ is $(w, J(w)) = (1.5, 0.58)$.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Case 5: $w=2.0$</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_w(x) = wx = 2x
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The computation of $f_w(x)$ is given below.</li>
    <li>For $x = 1, 2, 3$, $f_w(x)=2,4,6$ and its plot is given below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0309.png" width="40%" alt="fig09"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 9.</strong> Plot of $f_w(x)$ against $x$ for $w=2$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Cost function calculations are given below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(2.0) = \frac{1}{2 \times 3} \left[ (2 - 1)^2 + (4 - 2)^2 + (6 - 3)^2 \right] = \frac{1}{6} \times 14 = 2.33
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Another data point to plot $J(w)$ againt $w$ is $(w, J(w)) = (2.0, 2.33)$.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The data generated for the plot of $J(w)$ against $w$ is summarised in table below.</li>
  </ul>
</div>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 1.</strong> Computed values of $J(w)$ against $w$.</p>

<div style="font-size: 52px; line-height: 2.0;">

|$w$|$J(w)$|
|:---|:---|
|0.0|2.33|
|0.5|0.58|
|1.0|0.00|
|1.5|0.58|
|2.0|2.33|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The plot of $J(w)$ against $w$ is shown in figure below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0310.png" width="40%" alt="fig10"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 10.</strong> Plot of cost function against weights.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>It can be observed that minimum value of $J(w)$ is at $w=1$ which is the optimum value for the optimization problem given below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{aligned}
    & \min_w J(w)
\end{aligned}
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{aligned}
    & \min_{1.0} J(1.0) = 0.00
\end{aligned}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A python program which optimizes the cost function and plots it is given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
import numpy as np
import matplotlib.pyplot as plt

def predict(w, x):
    f = w*x
    return f

def cost(w, x, y):
    j = (1/6)*sum((y-x)**2)
    return j

i = 5
ws = [0, 0.5, 1.0, 1.5, 2.0]
#ws = np.linspace(-0.5, 2.5, 100)
Js = []
for w in ws:
    x = np.array([1, 2, 3])
    y = predict(w, x)
    Js.append(cost(w, x, y))
    plt.scatter (x, x, marker="X", c="r", s=80)
    plt.plot(x, y, '-b', linewidth=3)
    plt.xlim([0, 3.5])
    plt.ylim([0, 6.5])
    plt.xticks([0, 1, 2, 3], size=18, weight="bold")
    plt.yticks([0, 1, 2, 3, 4, 5, 6], size=18, weight="bold")
    plt.xlabel("x", size=18, weight="bold")
    plt.ylabel("y", size=18, weight="bold")
    plt.tight_layout()
    plt.savefig(f"030{i}.png")
    plt.show()
    i += 1

print(Js)

plt.scatter(ws, Js, marker="X", s=80, c="r")
plt.plot(ws, Js, "-b", linewidth=3.0)
plt.xticks([0.0, 0.5, 1.0, 1.5, 2.0], size=18, weight="bold", rotation="vertical")
plt.yticks(size=18, weight="bold")
plt.xlabel("w", size=18, weight="bold")
plt.ylabel("J(w)", size=18, weight="bold")
plt.tight_layout()
plt.show()
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If we comment out the statement <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">ws = [0, 0.5, 1.0, 1.5, 2.0]</code> and uncomment the line <code style="background-color: #dadada; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">#ws = np.linspace(-0.5, 2.5, 100)</code>, we get a smooth plot of $J(w)$ against $w$ as shown below.</li>
  </ul>
</div>

<br><br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0311.png" width="50%" alt="fig11"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 11.</strong> Plot of $J(w)$ against $w$.</figcaption>
</figure><br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Visualization and Intuition into Cost Function in Higher Dimensions</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the previous section, we developed and optimized the cost function in one dimension.</li>
    <li>Now, we generalize it in two dimensions and use it for understanding in higher dimensions.</li>
    <li>The code below shows a surface plot on left side and contour plot on right side.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
import numpy as np
import matplotlib.pyplot as plt

# Generate data
x = np.linspace(-3, 3, 100)
y = np.linspace(-3, 3, 100)
X, Y = np.meshgrid(x, y)
Z = X**2 + Y**2

# Create plots side by side
fig = plt.figure(figsize=(12, 5))

# Surface plot
ax1 = fig.add_subplot(1, 2, 1, projection='3d')
surf = ax1.plot_surface(X, Y, Z, cmap='viridis')
ax1.set_title('Surface Plot: z = x^2 + y^2')
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.set_zlabel('z')
fig.colorbar(surf, ax=ax1, shrink=0.5, aspect=10, location='right')

# Contour plot
ax2 = fig.add_subplot(1, 2, 2)
contour = ax2.contourf(X, Y, Z, cmap='viridis')
ax2.set_title('Contour Plot: z = x^2 + y^2')
ax2.set_xlabel('x')
ax2.set_ylabel('y')

plt.tight_layout()
plt.show()
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the code is shown below.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0312.png" width="90%" alt="fig12"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 12.</strong> Surface and contour plots showing optimal points.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The minimum bottom in the surface plot and the exact middle point on the contour plot are the optimum points which minimize the function.</li>
    <li>The surface plot can be rotated with mouse to better visualize the optimization point.</li>
    <li>On a contour line, the height of the function is the same.</li>
    <li>In one and two parameter estimations, although the visualizations change but the function value is minimum in both cases.</li>
    <li>In the same way in higher dimensions, the visualization is not possible, however, the minimum value of the cost function is the optimum point for the cost function.</li>
    <li>The following figure helps to clarify that the height on a same contour line is the same.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0313.png" width="80%" alt="fig13"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 13.</strong> Mount Fuji's 3d image (left) and contour image (right).</figcaption>
</figure>
<br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">9. Gradient Descent Method of optimization</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Gradient descent method is used for optimization of the cost function.</li>
    <li>This method is used in machine learning in various algorithms.</li>
    <li>Even, the deep learning models like neural networks also use gradient descent method.</li>
    <li>Gradient descent (GD) method is used to minimize any function and not only the cost function in linear regression.</li>
    <li>Now, we use GD method to minimize the cost function $J(w, b)$.</li>
    <li>GD also works in multi dimensions the same way as we are going to apply it in two dimensional case.</li>
    <li>We start with some initial guess value e.g., $w=0, b=0$.</li>
    <li>It is also possible that a function has several peaks and troughs and we have to find the extreme minimum of all troughs as shown below.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0314.png" width="80%" alt="fig14"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 14.</strong> Local and global minimas in optimization problems.</figcaption>
</figure>
<br>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">The Classic Example</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The most commonly used example in optimization is to go downhill in a mountain range.</li>
    <li>If you are standing on a peak, you see all around you which direction to choose to reach the downhill the fastest.</li>
    <li>The steepest descent method gives that direction.</li>
    <li>If you take a small step in the direction of steepest descent, you reach the valley the fastest.</li>
    <li>After taking one step in the steepest descent direction, the steepest descent direction is again checked before taking the next step.</li>
    <li>This continued approach will take you the fastest in the valley.</li>
    <li>A pictorial representation is shown in figure below.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0315.png" width="60%" alt="fig15"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 15.</strong> Steepest descent method to minimize a function.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>One of the challenges in steepest descent method is that the initial guess decides the minimum point which may by a local minumum.</li>
    <li>This is shown in figure below.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0316.png" width="70%" alt="fig16"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 16.</strong> Different minima with different initial guesses in an optimization problem.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>This is your good luck that the cost function is a convex optimization problem where we have only one minimum.</li>
    <li>So whatever the initial guess is, you always reach the optimum point.</li>
    <li>The neural networks are non-convex optimization problem where you will be in a bad luck.</li>
    <li>However, we will find some way to get rid of this problem of finding global minimum out of several minima.</li>
    <li>Now, we start to implement the algorithm of GD method.</li>
    <li>We decide the initial guess values of $w$ and $b$ and use them in the following equations.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w := w - \alpha \frac{\partial}{\partial w}J(w, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
b := b - \alpha \frac{\partial}{\partial b}J(w, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The above two equations are not the mathematical truth assertions but the assignments of right hand side computations into the variable on the left hand side.</li>
    <li>The symbol $\alpha$ is called the learning rate and its value is greater than 0.</li>
    <li>A small value of $\alpha$ means moving a little step in the GD direction and a large value of $\alpha$ means moving a long step in the direction of GD.</li>
    <li>The derivative represents the direction of steepest descent.</li>
    <li>After completion of one iteration, the values of $w$ and $b$ computed from the previous iteration are used in the next iteration.</li>
    <li>There are two equations and we need a simultaneous update of $w$ and $b$.</li>
    <li>An incorrect update is shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
temp\_w = w - \alpha \frac{\partial}{\partial w}J(w, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\textcolor{red}{w} = temp\_w
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
temp\_b = b - \alpha \frac{\partial}{\partial b}J(\textcolor{red}{w}, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
b = temp\_b
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The correct simultaneous update is shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
temp\_w = \textcolor{green}{w} - \alpha \frac{\partial}{\partial w}J(w, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
temp\_b = b - \alpha \frac{\partial}{\partial b}J(\textcolor{green}{w}, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w = temp\_w
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
b = temp\_b
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The correct algorithm confirms that the values of $w$ and $b$ are the same in $J(w, b)$ in the computation of $temp\_w$ and $temp\_b$.</li>
    <li>The learning rate $\alpha$ determines the step size.</li>
    <li>In order to understand the role of $\alpha$, we again simplify the cost function as a function of $w$ only i.e., $J(w)$.</li>
    <li>Our update is changed to</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w = w - \alpha \frac{\partial}{\partial w}J(w)
$$
</div>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Question: Positive or negative? Prove your claim.</h3>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0317.png" width="60%" alt="fig17"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 17.</strong> Is the slope positive or negative (100\$ question). Prove your claim (100,000\$ question).</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For an initial guess $w_0$ if the slope is positive, the new guess $w_1$ will fulfill the codition $w_1 \lt w_0$.</li>
    <li>As $\frac{\partial}{\partial w}J(w) > 0$, $\alpha \times \frac{\partial}{\partial w}J(w) > 0$ and $w - \alpha \times \frac{\partial}{\partial w}J(w)$ will be smaller than initial guess.</li>
    <li>Mathematically,</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - \alpha \frac{\partial}{\partial w}J(w)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - \alpha . (positive
\;\;number)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - positive\;\;number \implies w_1 \lt w_0
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The above mathematics is represented graphically below.</li>
    <li>So, the algorithm is converging.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0318.png" width="60%" alt="fig18"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 18.</strong> The convergence of optimization algorithm with initial guess giving positive slope of the cost function.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Conversely, if the slope is negative, then, mathematically $w_1 > w_0$ which still gives convergence of the cost function.</li>
    <li>Graphically it is shown below.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0319.png" width="60%" alt="fig19"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 19.</strong> The convergence of optimization algorithm with initial guess giving negative slope of the cost function.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Mathematically, we can say</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - \alpha \frac{\partial}{\partial w}J(w)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - \alpha . (negative\;\;number)
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 - negative\;\;number
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
w_1 = w_0 + positive\;\;number \implies w_1 > w_0
$$
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Effect of Learning Rate on Convergence</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If the learning rate $\alpha$ is too small, the algorithm converges very slow.</li>
    <li>If the learning rate $\alpha$ is too large, the algorithm diverges as shown in the figure below.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0320.png" width="60%" alt="fig20"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 20.</strong> Divergence of algorithm due to large learning rate $\alpha$.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So, sometimes it is our good luck that our initial guess is close to minimum but bad choice of $\alpha$ diverges the algorithm.</li>
    <li>The convergence in higher dimensions is a tangent hyperplane at the minimum point of hyperquadratic surface.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0321.png" width="70%" alt="fig1221"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 21.</strong> Optimization in higher dimensions.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If the learning rate is kept small and the initial guess is too far from the minimum, the derivative term is large and the updated value of $w$ is far from the initial guess.</li>
    <li>But, as the guess values get closer to the minimum, the derivative term becomes small and the convergence rate also decreases.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Linear Regression Model</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
f_{w, b}(x) = wx + b
$$
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Cost Function</h3>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w, b) = \frac{1}{2m}\sum_{i=1}^m \left( f_{w, b} ( x^{(i)} ) - y^{(i)} \right)^2
$$
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Gradient Descent Algorithm</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">repeat until convergence $\{$</p>


<div style="font-size: 52px; line-height: 2.0;">
$$
w = w - \alpha \; \boxed{\frac{\partial}{\partial w} J(w, b)} \rightarrow \frac{1}{m} \sum_{i=1}^m \left( f_{w, b}(x^{(i)}) - y^{(i)} \right)x^{(i)}
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
b = b - \alpha \; \boxed{\frac{\partial}{\partial b} J(w, b)} \rightarrow \frac{1}{m} \sum_{i=1}^m \left( f_{w, b}(x^{(i)}) - y^{(i)} \right)
$$
</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">$\}$</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The development of python program for the above mathematics gives the supervised learning linear regression model.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">10. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A linear regression model is $f_{w, b}(x) = wx + b$.</li>
    <li>The parameters $w$ and $b$ fit the line through the data.</li>
    <li>The cost function for a linear regression model is the squared error cost function which is given by the relation</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
J(w, b) = \frac{1}{2m} \sum_{i=1}^m \left( \hat y^{(i)} - y^{(i)} \right)^2
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The optimization problem (below) for the cost function gives the best fit line parameters.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\min_{w, b}J(w, b)
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The gradient descent algorithm is used to optimize the cost function.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">11. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">What is a linear regression model? By taking suitable examples, show that the parameters of the equations are responsible to get a best fit line.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">For the linear regression model $f_{w, b}(x) = wx + b$, develop a suitable cost function. By taking the most simplified form of the model and the cost function, show how the optimization works to find the parameter for the best fit line.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 3</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">What is the gradient descent algorithm? Show its working in optimizing the cost function for linear regression model. What is the effect of learning rate in gradient descent algorithm? Illustrate with the help of figures.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 4</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Develop a python program which reads data from a text (*.txt) or comma separated values (*.csv) files and then implements the gradient descent method to optimize the cost function for linear regression problem. The program must compute the coefficients $w$ and $b$, plot the data and the regression line, and compute the predict the output for new input features. Test your program with the data in the file data.csv (<a href="../programs/data.csv" download>click here to downlad the file</a>).</p>