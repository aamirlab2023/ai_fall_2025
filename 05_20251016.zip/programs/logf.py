import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

font_props = FontProperties(size=26, weight='bold')

x = np.linspace(0.01, 10, 100)
y = np.log10(x)

plt.figure(figsize=(10, 7))
plt.plot(x, y, '-b', linewidth=3, label='log(f)')
plt.plot(x, -y, '-r', linewidth=3, label='-log(f)')
plt.plot([0, 10],[0, 0], '-k', linewidth=3)
plt.plot([0, 0],[-2, 2], '-k', linewidth=3)
plt.plot([1, 1],[-2, 2], '--g', linewidth=3)
plt.plot([0, 1],[0, 0], '--m', linewidth=3)
plt.plot([1, 1],[0, 1.5], '--m', linewidth=3)
plt.plot([1, 0],[1.5, 1.5], '--m', linewidth=3)
plt.plot([0, 0],[1.5, 0], '--m', linewidth=3)
plt.xlabel("f(x)", size=26, weight='bold')
plt.ylabel("log(f(x))", size=26, weight='bold')
plt.xticks([0, 5, 10], size=26, weight='bold')
plt.yticks([-2, -1, 0, 1, 2], size=26, weight='bold')
plt.legend(prop=font_props)
plt.tight_layout()
plt.savefig("/home/aamir/aamirlab/megadrive/fall_2025/ce_451/lectures/topic_05/images/0512a.png")
plt.show()