import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

font_props = FontProperties(size=26, weight='bold')

x = np.linspace(0.01, 1, 100)
y = -np.log10(x)

plt.plot(x, y, '-b', linewidth=3)
plt.plot([-0.1, 1], [0, 0], '-k', linewidth=3)
plt.plot([0, 0], [-0.2, 2], '-k', linewidth=3)
plt.scatter(0.8, -np.log10(0.8), s=50, c='g')
plt.plot([0.8, 0.8], [0.0, -np.log10(0.8)], '-r', linewidth=3, label='loss')
plt.scatter(0.1, -np.log10(0.1), s=50, c='g')
plt.plot([0.1, 0.1], [0.0, -np.log10(0.1)], '-r', linewidth=3)
plt.xlabel("f(x)", size=26, weight='bold')
plt.ylabel("-log(f(x))=Loss", size=26, weight='bold')
plt.xticks([0, 0.5, 1.0], size=26, weight='bold')
plt.yticks([0, 1, 2], size=26, weight='bold')
plt.legend(prop=font_props)
plt.tight_layout()
plt.savefig("/home/aamir/aamirlab/megadrive/fall_2025/ce_451/lectures/topic_05/images/0513.png")
plt.show()

x = np.linspace(0.01, 1, 100)
y = -np.log10(1-x)

plt.plot(x, y, '-b', linewidth=3)
plt.plot([-0.1, 1], [0, 0], '-k', linewidth=3)
plt.plot([0, 0], [-0.2, 2], '-k', linewidth=3)
plt.scatter(0.8, -np.log10(1-0.8), s=50, c='g')
plt.plot([0.8, 0.8], [0.0, -np.log10(1-0.8)], '-r', linewidth=3, label='loss')
plt.scatter(0.1, -np.log10(1-0.1), s=50, c='g')
plt.plot([0.1, 0.1], [0.0, -np.log10(1-0.1)], '-r', linewidth=3)
plt.xlabel("f(x)", size=26, weight='bold')
plt.ylabel("-log(1-f(x))=Loss", size=26, weight='bold')
plt.xticks([0, 0.5, 1.0], size=26, weight='bold')
plt.yticks([0, 1, 2], size=26, weight='bold')
plt.legend(prop=font_props)
plt.tight_layout()
plt.savefig("/home/aamir/aamirlab/megadrive/fall_2025/ce_451/lectures/topic_05/images/0514.png")
plt.show()